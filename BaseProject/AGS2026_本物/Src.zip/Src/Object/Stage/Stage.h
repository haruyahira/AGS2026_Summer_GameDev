#pragma once

#include <map>
#include <vector>
#include <set>
#include <DxLib.h>

#include "../../Manager/ResourceManager.h"
#include "../../Utility/AsoUtility.h"
#include "../../Common/Vector3.h"
#include "../Common/Transform.h"
#include "../Furniture/Furniture.h"
#include "../Furniture/StoneDevice.h"
#include "../Furniture/CeilingLight.h"
#include "../Item.h"
#include "../../Shader/Light/LightManager.h"
#include "../../Shader/Light/LightEffect.h"

class ResourceManager;
class WarpStar;
class Planet;
class Player;
class Wall;

class Stage
{
public:

	// �X�e�[�W�̐؂�ւ��Ԋu
	static constexpr float TIME_STAGE_CHANGE = 1.0f;

	// �Ƌ�̐݌v�}
	struct FurnitureData
	{
		ResourceManager::SRC modelSrc;
		Vector3 pos;
		Vector3 scl;
		Vector3 rot;
	};

	Stage(Player* player);
	~Stage(void);

	void Init(void);
	void Update(void);
	void Draw(void);

	// �X�e�[�W�ύX
	void ChangeStage(NAME type);

	// �ΏۃX�e�[�W���擾
	Planet* GetPlanet(NAME type);

	void CreateFurniture(const FurnitureData& data);
	void CreateCeilingLight(const FurnitureData& data);
	void DrawDepthMaskForExternal3D(void);

	bool IsLineBlocked(const VECTOR& from, const VECTOR& to) const;
private:

	LightEffect lightEffect_;
	// �V���O���g���Q��
	ResourceManager& resMng_;

	Player* player_;
	StoneDevice* stoneDevice_;

	// �X�e�[�W�A�N�e�B�u�ɂȂ��Ă���f���̏��
	NAME activeName_;
	Planet* activePlanet_;

	// �f��
	std::map<NAME, Planet*> stages_;

	// �Ƌ�
	std::vector<Furniture*> furnitures_;
	std::vector<Furniture*> glassFurnitures_;
	std::vector<CeilingLight*> ceilingLights_;
	std::vector<VECTOR> ceilingLightBeamPositions_;
	// ���[�v�X�^�[
	std::vector<WarpStar*> warpStars_;

	// ���Planet
	Planet* nullPlanet = nullptr;

	float step_;

	// �ŏ��̘f��
	void MakeMainStage(void);

	void CreateFirstStage(void);

	// �A�C�e��
	std::vector<Item*> items_;

	int itemCount_[(int)Item::TYPE::MAX];
	int registeredItemCount_[(int)Item::TYPE::MAX];
	int stolenItemCount_[(int)Item::TYPE::MAX];

	// ��������F3�̃m�[�gPC���E����悤�ɂ���
	static constexpr int MAX_ITEM_COUNT = 3;

	int lookingItemIndex_;
	bool isItemMax_;

	// �A�C�e���o�����n�_
	std::vector<VECTOR> itemSpawnPoints_;

	void CreateItem(
		Item::TYPE type,
		ResourceManager::SRC modelSrc,
		VECTOR pos,
		VECTOR scl);

	// ���n�_����m�[�gPC�������_������
	void CreateRandomLaptopItemsFromSpawnPoints(int count);

	int FindLookingItem(void);
	void UpdateItemPickup(void);

	bool HasAnyItem(void) const;
	void RegisterItemsToStoneDevice(void);
	void UpdateStoneDeviceRegister(void);

	void DrawItemUI(void) const;

	int GetTotalItemCount(void) const;

	int GetItemPrice(Item::TYPE type) const;
	int CalcStolenMoney(void) const;
	int CalcTotalMoney(void) const;
	int CalcRemainDay(void) const;


	void DrawCeilingLightBeams(void);
	void DrawOneCeilingLightBeam(const VECTOR& lightPos);
	int beamGraph_ = -1;

	void CreateBeamGraph(void);
	void CreateKitchenLight(const FurnitureData& data);

	void DrawDisc3D(
		const VECTOR& center,
		float radius,
		int div,
		int color
	);

	void UpdateFlashLightForShader(
		const VECTOR& cameraPos,
		const VECTOR& cameraTarget
	);


	int outlineRTColor_ = -1;
	int outlineRTNormal_ = -1;
	int outlineRTDepth_ = -1;

	int outlinePostPS_ = -1;

	bool InitPostOutline(void);
	void ReleasePostOutline(void);
	void DrawOpaqueSceneForOutline(
		const VECTOR& cameraPos, const VECTOR& cameraTarget);
	void DrawPostOutline(void);



	
};
