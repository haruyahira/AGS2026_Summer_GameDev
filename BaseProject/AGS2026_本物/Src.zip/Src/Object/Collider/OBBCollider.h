#pragma once
#include <DxLib.h>

class OBBCollider
{
public:

    OBBCollider();

    OBBCollider(
        VECTOR center,
        VECTOR halfSize,
        VECTOR axisX,
        VECTOR axisY,
        VECTOR axisZ);

    // �_�Ƃ̓����蔻��
    bool CheckCollision(VECTOR point) const;


    // �_����OBB�܂ł̋�����2��
    float GetDistanceSq(VECTOR point) const;

    // ��ԋ߂��_
    VECTOR GetClosestPoint(VECTOR point) const;


    // �f�o�b�O�`��
    void DrawDebug(unsigned int color) const;

    bool ResolveCollisionXZ(
        VECTOR& pos,
        float radius,
        float bottomY,
        float topY) const;


    bool ResolveCollisionTop(
        VECTOR& pos,
        float radius,
        float bottomY,
        float topY) const;


    bool ResolveCollisionBottom(
        VECTOR& pos,
        float radius,
        float bottomY,
        float topY) const;


    bool ResolveSphere(
        VECTOR& pos,
        float radius) const;

    bool IsHitSegment(VECTOR start, VECTOR end) const;
    void DrawOutline(unsigned int color, bool isVerticalOnly = false) const;

private:

    // ���S���W
    VECTOR center_;

    // �����T�C�Y
    VECTOR halfSize_;

    // OBB�̃��[�J����
    VECTOR axisX_;
    VECTOR axisY_;
    VECTOR axisZ_;
};