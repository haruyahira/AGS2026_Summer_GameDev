#include "CeilingLight.h"
#include <DxLib.h>
#include <math.h>

CeilingLight::CeilingLight(
    const Transform* trans)
{
    trans_ =
        std::make_shared<Transform>(*trans);
}

CeilingLight::~CeilingLight()
{
}

void CeilingLight::Init()
{
}

void CeilingLight::Update()
{
    trans_->Update();
}

void CeilingLight::Draw()
{
    // �ʏ�`��
    MV1DrawModel(trans_->modelId);

    // ���f�����̂������������Č�����悤�ɏd�˕`��
    SetUseZBuffer3D(TRUE);
    SetWriteZBuffer3D(FALSE);

    SetDrawBlendMode(
        DX_BLENDMODE_ADD,
        80
    );

    SetDrawBright(
        255,
        235,
        190
    );

    MV1DrawModel(trans_->modelId);

    SetDrawBright(
        255,
        255,
        255
    );

    SetDrawBlendMode(
        DX_BLENDMODE_NOBLEND,
        0
    );

    SetWriteZBuffer3D(TRUE);
}

static void DrawGlowDisc(
    VECTOR center,
    float radius,
    int div,
    int color)
{
    VECTOR prev =
        VGet(
            center.x + radius,
            center.y,
            center.z
        );

    for (int i = 1; i <= div; i++)
    {
        float angle =
            DX_TWO_PI_F * i / div;

        VECTOR current =
            VGet(
                center.x + cosf(angle) * radius,
                center.y,
                center.z + sinf(angle) * radius
            );

        DrawTriangle3D(
            center,
            prev,
            current,
            color,
            TRUE
        );

        prev = current;
    }
}

void CeilingLight::DrawGlow()
{
    VECTOR pos =
        trans_->GetPos();

    // �V��̉��ʂɔ����ʂ�������悤�ɏ���������
    pos.y -= 4.0f;

    // �d�v�F
    // Z�o�b�t�@�͎g���B�ǂ̉��Ȃ猩���Ȃ�����B
    // ������Z�������݂͂��Ȃ��B
    SetUseZBuffer3D(TRUE);
    SetWriteZBuffer3D(FALSE);
    SetUseBackCulling(FALSE);

    // �O���̂��炩����
    SetDrawBlendMode(
        DX_BLENDMODE_ADD,
        45
    );

    DrawGlowDisc(
        pos,
        18.0f,
        32,
        GetColor(255, 210, 130)
    );

    // �����̔���������
    SetDrawBlendMode(
        DX_BLENDMODE_ADD,
        160
    );

    DrawGlowDisc(
        pos,
        9.0f,
        32,
        GetColor(255, 245, 220)
    );

    SetDrawBlendMode(
        DX_BLENDMODE_NOBLEND,
        0
    );

    SetUseBackCulling(TRUE);
    SetWriteZBuffer3D(TRUE);
}
VECTOR CeilingLight::GetPos() const
{
    return trans_->GetPos();
}