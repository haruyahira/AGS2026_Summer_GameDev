#pragma once
#include "Furniture.h"
#include "../Furniture/LightBlocker.h"
#include "../Collider/OBBCollider.h"

class Wall 
    : public Furniture
    , public LightBlocker
{
public:
    // �R���X�g���N�^
    Wall(const Transform* trans, float rotY);

    void Init() override;
    void Update() override;
    void Draw() override;
    bool ResolveCollision(
        VECTOR& pos,
        float radius,
        float bottomY,
        float topY) override;

    bool ResolveCameraCollision(
        VECTOR& cameraPos,
        float radius) override;

    bool IsBlockingSight(VECTOR start, VECTOR end) const override;
    void DrawOutline(unsigned int color, bool isVerticalOnly = true) const;
 
    VECTOR GetPos() const;

    VECTOR GetAxisX() const;

    VECTOR GetAxisZ() const;

    VECTOR GetHalfSize() const;

private:
    OBBCollider obbCollider_;

    // �ǂ�Y��]
    float rotY_;
    VECTOR axisX_;
    VECTOR axisZ_;
    VECTOR center_;
};