#include "Wall.h"
#include "../../Manager/InputManager.h"

// �R���X�g���N�^
Wall::Wall(const Transform* trans, float rotY)
    : Furniture(NAME::WALL, trans) {
    rotY_ = rotY;
}

// ---------------------------------------------------------
// �ǃp�����[�^
// ---------------------------------------------------------
float wallH = 400.0f;   // ����
float wallW = 440.0f;   // ����
float wallD = 60.0f;    // ����

float slideX = 0.0f;
float slideY = 0.0f;
float slideZ = 0.0f;
// ---------------------------------------------------------

// ������
void Wall::Init() {


    VECTOR pos = trans_.GetPos();

    // �ǂ̎��T�C�Y
    float w = wallW * trans_.scl.x;
    float h = wallH * trans_.scl.y;
    float d = wallD * trans_.scl.z;

    // �ǂ̒��S
    center_ = VAdd(
        pos,
        VGet(
            slideX,
            slideY + h / 2.0f,
            slideZ
        )
    );

    // Y��]���g��
    float c = cosf(rotY_);
    float s = sinf(rotY_);

    axisX_ = VGet(c, 0.0f, -s);
    axisZ_ = VGet(s, 0.0f, c);

    VECTOR axisY = VGet(0.0f, 1.0f, 0.0f);

    obbCollider_ = OBBCollider(
        center_,
        VGet(w / 2.0f, h / 2.0f, d / 2.0f),
        axisX_,
        axisY,
        axisZ_
    );


}

// �X�V
void Wall::Update(void) {
#ifdef _DEBUG
    auto& ins = InputManager::GetInstance();
    bool changed = false;

    // W�L�[�ő���
    if (CheckHitKey(KEY_INPUT_W)) {

        // Shift �� �ʒu�ړ�
        if (CheckHitKey(KEY_INPUT_LSHIFT)) {
            if (ins.IsTrgDown(KEY_INPUT_RIGHT)) { slideX += 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_LEFT)) { slideX -= 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_UP)) { slideZ += 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_DOWN)) { slideZ -= 1.0f; changed = true; }
        }
        // �ʏ� �� �T�C�Y�ύX
        else {
            if (ins.IsTrgDown(KEY_INPUT_UP)) { wallH += 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_DOWN)) { wallH -= 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_RIGHT)) { wallW += 1.0f; changed = true; }
            if (ins.IsTrgDown(KEY_INPUT_LEFT)) { wallW -= 1.0f; changed = true; }
        }
    }

    if (changed) Init();
#endif
}

// �`��
void Wall::Draw(void) {

    {
        trans_.Update();

        // ���f���`��
        MV1DrawModel(trans_.modelId);


#ifdef _DEBUG
        // OBB�����蔻��\��
        obbCollider_.DrawDebug(GetColor(255, 0, 0));
#endif
    }

}

bool Wall::ResolveCollision(
    VECTOR& pos,
    float radius,
    float bottomY,
    float topY)
{
    return obbCollider_.ResolveCollisionXZ(
        pos,
        radius,
        bottomY,
        topY);
}

bool Wall::ResolveCameraCollision(
    VECTOR& cameraPos,
    float radius)
{
    return obbCollider_.ResolveSphere(
        cameraPos,
        radius);
}

bool Wall::IsBlockingSight(VECTOR start, VECTOR end) const
{
    return obbCollider_.IsHitSegment(start, end);
}

void Wall::DrawOutline(unsigned int color, bool isVerticalOnly) const
{
    obbCollider_.DrawOutline(color, isVerticalOnly);
}

VECTOR Wall::GetPos() const
{
    return center_;
}
VECTOR Wall::GetAxisX() const
{
    return axisX_;
}

VECTOR Wall::GetAxisZ() const
{
    return axisZ_;

}
VECTOR Wall::GetHalfSize() const
{

    float w =
        wallW * trans_.scl.x;

    float h =
        wallH * trans_.scl.y;

    float d =
        wallD * trans_.scl.z;

    return VGet(
        w * 0.5f,
        h * 0.5f,
        d * 0.5f
    );

}