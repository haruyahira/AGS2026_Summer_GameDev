
#pragma once
#include "Furniture.h"

class Showcase : public Furniture {
public:
    // �R���X�g���N�^
    Showcase(const Transform* trans);

    void Init() override;
    void Update() override;
    void Draw() override;
};