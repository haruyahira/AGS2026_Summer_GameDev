#include "StoneDevice.h"

#include "../../Manager/InputManager.h"
#include "../../Manager/SceneManager.h"
#include "../../Utility/AsoUtility.h"
#include "../Player.h"

StoneDevice::StoneDevice(Player* player)
    : player_(player)
    , resMng_(ResourceManager::GetInstance())
{
    isActive_ = true;
    isSinking_ = false;
    sinkLength_ = 0.0f;
    startTime_ = 0;
}

StoneDevice::~StoneDevice(void)
{
}

void StoneDevice::Init(void)
{
    transform_.SetModel(
        resMng_.LoadModelDuplicate(ResourceManager::SRC::RETURN_POINT));

    // ���u�̈ʒu
    // �D���ȏꏊ�ɒ������Ă�������
    transform_.pos = { -1618.0f, -80.0f,  712.0f }; 

    // ���u�̑傫��
    transform_.scl = { 1.0f, 1.0f, 1.0f };

    // ���u�̌���
    transform_.quaRot = Quaternion::Euler(
        0.0f,
        AsoUtility::Deg2RadF(0.0f),
        0.0f
    );

    transform_.Update();

    isActive_ = true;
    isSinking_ = false;
    sinkLength_ = 0.0f;

    // ��������5���J�E���g�J�n
    startTime_ = GetNowCount();
}

void StoneDevice::Update(void)
{ 
if (!isActive_)
{
    return;
}

int nowTime = GetNowCount();
int elapsedTime = nowTime - startTime_;

// 5���o�߂����璾�ݎn�߂�
if (elapsedTime >= LIMIT_TIME_MS && !isSinking_)
{
    StartSinking();
}

// ����ł����
if (isSinking_)
{
    UpdateSinking();
    return;
}
}

void StoneDevice::Draw(void)
{
    if (!isActive_)
    {
        return;
    }

    MV1DrawModel(transform_.modelId);

}

bool StoneDevice::IsActive(void) const
{
    return isActive_;
}

void StoneDevice::StartSinking(void)
{
    isSinking_ = true;
}

void StoneDevice::UpdateSinking(void)
{
    sinkLength_ += SINK_SPEED;

    // ���ɒ��߂�
    transform_.pos.y -= SINK_SPEED;
    transform_.Update();

    // ��苗�����񂾂犮�S�ɖ�����
    if (sinkLength_ >= SINK_END_LENGTH)
    {
        isActive_ = false;
        isSinking_ = false;
    }
}

bool StoneDevice::IsNearPlayer(void) const
{
    if (player_ == nullptr)
    {
        return false;
    }

    VECTOR playerPos = player_->GetPos();
    VECTOR devicePos = transform_.pos;

    // �����͖������āAXZ���ʂŋ���������
    float dx = playerPos.x - devicePos.x;
    float dz = playerPos.z - devicePos.z;

    float distSq = dx * dx + dz * dz;
    float rangeSq = CHECK_RANGE * CHECK_RANGE;

    return distSq <= rangeSq;
}

void StoneDevice::DrawGuide(void) const
{

   /* DrawString(
        20,
        80,
        "F�L�[�ŃA�C�e���o�^ / E�L�[�ŒE�o",
        GetColor(255, 255, 255)
    );*/

}

void StoneDevice::DrawTimer(void) const
{
    int nowTime = GetNowCount();
    int elapsedTime = nowTime - startTime_;

    int remainTime = LIMIT_TIME_MS - elapsedTime;

    if (remainTime < 0)
    {
        remainTime = 0;
    }

    int remainSec = remainTime / 1000;
    int minute = remainSec / 60;
    int second = remainSec % 60;

    DrawFormatString(
        20,
        105,
        GetColor(255, 255, 0),
        "���u���ł܂� %d:%02d",
        minute,
        second
    );
}

void StoneDevice::DrawUI(void) 
{

    if (!isSinking_ && IsNearPlayer())
    {
        DrawGuide();
    }

    DrawTimer();
}