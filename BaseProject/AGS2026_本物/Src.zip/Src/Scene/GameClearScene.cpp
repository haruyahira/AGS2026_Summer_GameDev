#include <DxLib.h>
#include "../Manager/InputManager.h"
#include "../Manager/SceneManager.h"
#include "../Application.h"
#include "GameClearScene.h"

GameClearScene::GameClearScene(void)
{
}

GameClearScene::~GameClearScene(void)
{
}

void GameClearScene::Init(void)
{
    // �K�v�Ȃ炱���ŉ摜��BGM��ǂݍ���
}

void GameClearScene::Update(void)
{
    InputManager& ins = InputManager::GetInstance();

    // R�L�[�ōŏ����������x
    if (ins.IsTrgDown(KEY_INPUT_R))
    {
        SceneManager::GetInstance().ResetGameResultData();
        SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME);
        return;
    }

    // T�L�[�Ń^�C�g���֖߂�
    if (ins.IsTrgDown(KEY_INPUT_T))
    {
        SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::TITLE);
        return;
    }
}

void GameClearScene::Draw(void)
{
    // �w�i
    DrawBox(
        0,
        0,
        Application::SCREEN_SIZE_X,
        Application::adjustedSizeY_,
        GetColor(10, 20, 50),
        TRUE
    );

    // �^�C�g������
    DrawString(
        240,
        160,
        "GAME CLEAR!",
        GetColor(255, 255, 0)
    );

    // ����
    DrawString(
        220,
        250,
        "R : RETRY",
        GetColor(255, 255, 255)
    );

    DrawString(
        220,
        290,
        "T : TITLE",
        GetColor(255, 255, 255)
    );
}