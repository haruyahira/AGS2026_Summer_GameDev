#include <DxLib.h>

#include "ResultScene.h"
#include "../Manager/SceneManager.h"
#include "../Manager/InputManager.h"

ResultScene::ResultScene(void)
{
    remainDay_ = 0;
    stolenMoney_ = 0;
    totalMoney_ = 0;

    targetMoney_ = 0;
    needMoney_ = 0;
      
}

ResultScene::~ResultScene(void)
{
}

void ResultScene::Init(void)
{
    SceneManager& sceneMng = SceneManager::GetInstance();

    remainDay_ = sceneMng.GetResultRemainDay();
    stolenMoney_ = sceneMng.GetResultStolenMoney();
    totalMoney_ = sceneMng.GetResultTotalMoney();

    targetMoney_ = sceneMng.GetTargetMoney();
    needMoney_ = sceneMng.GetNeedMoney();


    SetMouseDispFlag(TRUE);
    InputManager::GetInstance().SetFixMouse(false);
}
void ResultScene::Update(void)
{
    InputManager& ins = InputManager::GetInstance();

    if (ins.IsTrgDown(KEY_INPUT_SPACE))
    {
        if (SceneManager::GetInstance().CanGoNextDay())
        {
            // ���̓���
            SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAME);
            return;
        }

        // �ŏI���I����
        if (SceneManager::GetInstance().IsGameClear())
        {
            // ��������ł��Ȃ� && �ڕW���z�B��
            SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAMECLEAR);
            return;
        }
        else
        {
            // �������B���Ȃ�Q�[���I�[�o�[
            SceneManager::GetInstance().ChangeScene(SceneManager::SCENE_ID::GAMEOVER);
            return;
        }
    }
}
void ResultScene::Draw(void)
{
    int white = GetColor(255, 255, 255);
    int yellow = GetColor(255, 230, 80);
    int cyan = GetColor(100, 255, 255);
    int red = GetColor(255, 100, 100);

    DrawString(
        260,
        80,
        "RESULT",
        yellow
    );

    DrawFormatString(
        220,
        140,
        white,
        "�c��%d��",
        remainDay_
    );

    DrawFormatString(
        220,
        190,
        white,
        "���񓐂񂾋��z�F%d�~",
        stolenMoney_
    );

    DrawFormatString(
        220,
        240,
        cyan,
        "���v���z�F%d�~",
        totalMoney_
    );

    DrawFormatString(
        220,
        290,
        yellow,
        "�ڕW���z�F%d�~",
        targetMoney_
    );

    if (needMoney_ > 0)
    {
        DrawFormatString(
            220,
            330,
            red,
            "�ڕW���z�܂ł���%d�~�I",
            needMoney_
        );
    }
    else
    {
        DrawString(
            220,
            330,
            "�ڕW���z�B���I",
            yellow
        );
    }

    if (remainDay_ > 0)
    {
        DrawString(
            220,
            390,
            "���̓��ɑ���",
            yellow
        );

        DrawString(
            220,
            430,
            "Space�F���̓���",
            white
        );
    }
    else
    {
        DrawString(
            220,
            390,
            "���ׂĂ̓������I�����܂���",
            red
        );

        DrawString(
            220,
            430,
            "Space�F���ʂ�",
            white
        );
    }
}