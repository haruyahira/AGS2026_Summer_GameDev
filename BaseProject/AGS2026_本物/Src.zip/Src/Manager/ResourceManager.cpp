#include <DxLib.h>
#include <memory>
#include <assert.h>
#include "../Application.h"
#include "Resource.h"
#include "ResourceManager.h"

ResourceManager* ResourceManager::instance_ = nullptr;

void ResourceManager::CreateInstance(void)
{
	if (instance_ == nullptr)
	{
		instance_ = new ResourceManager();
	}
	instance_->Init();
}

ResourceManager& ResourceManager::GetInstance(void)
{
	return *instance_;
}

void ResourceManager::Init(void)
{

	// �������܂��񂪁A�ǂ����Ă��g����������
	using RES = Resource;
	using RES_T = RES::TYPE;
	static std::string PATH_IMG = Application::PATH_IMAGE;
	static std::string PATH_MDL = Application::PATH_MODEL;
	static std::string PATH_EFF = Application::PATH_EFFECT;

	Resource* res;

	// �^�C�g���֘A--------------------------------------------------------------
	// �摜
	// �^�C�g���w�i�摜
	resourcesMap_.emplace(SRC::BACK_GROUND,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleBackground.png"));
	// �^�C�g�����S
	resourcesMap_.emplace(SRC::TITLE_LOGO,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleLogo.png"));
	// ���b�T�[�p���_
	resourcesMap_.emplace(SRC::TITLE_READ_PANDA,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleRedpanda2.png"));
	// �I����
	resourcesMap_.emplace(SRC::TITLE_SELECT,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleSelectNormal.png"));
	// �I���������蔻��p
	resourcesMap_.emplace(SRC::TITLE_SELECT2,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleSelectNormal2.png"));
	// �I�����i����X�^�[�g�j
	resourcesMap_.emplace(SRC::TITLE_SELECT_BRIGHT1,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleSelectBright1.png"));
	// �I�����i���郉���L���O�j
	resourcesMap_.emplace(SRC::TITLE_SELECT_BRIGHT2,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleSelectBright2.png"));
	// �I�����i����I���j
	resourcesMap_.emplace(SRC::TITLE_SELECT_BRIGHT3,
		std::make_unique<RES>(RES_T::IMG, PATH_IMG + "TitleSelectBright3.png"));
	//---------------------------------------------------------------------------

	// �Ƌ�
	// ��
	resourcesMap_.emplace(SRC::F_TABLE,
		std::make_unique<RES>(RES_T::MODEL, PATH_MDL + "Stage/F_Table.mv1"));

	// ��
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/floor.mv1");
	resourcesMap_.emplace(SRC::FLOOR, res);
	// �V�䃉�C�g
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/CeilingLight.mv1");
	resourcesMap_.emplace(SRC::CEILING_LIGHT, res);
	// ��
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/Wall.mv1");
	resourcesMap_.emplace(SRC::WALL, res);
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/Showcase_frame.mv1");
	resourcesMap_.emplace(SRC::F_F, res);
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/Showcase_grasu.mv1");
	resourcesMap_.emplace(SRC::F_G, res);
	// �S�[���n�_�A�[�i��
	res = new RES(RES_T::MODEL, PATH_MDL + "Stage/ReturnPoint.mv1");
	resourcesMap_.emplace(SRC::RETURN_POINT, res);
	res = new RES(RES_T::MODEL, PATH_MDL + "Item/Laptop.mv1");
	resourcesMap_.emplace(SRC::LAPTOP, res);



	//// �����o��
	//res = new RES(RES_T::IMG, PATH_IMG + "SpeechBalloon.png");
	//resourcesMap_.emplace(SRC::SPEECH_BALLOON, res);

	// �v���C���[
	res = new RES(RES_T::MODEL, PATH_MDL + "Player/Player.mv1");
	resourcesMap_.emplace(SRC::PLAYER, res);

	// �v���C���[�e
	res = new RES(RES_T::IMG, PATH_IMG + "Shadow.png");
	resourcesMap_.emplace(SRC::PLAYER_SHADOW, res);


	// �G
	res = new RES(RES_T::MODEL, PATH_MDL + "Enemy/Enemy.mv1");
	resourcesMap_.emplace(SRC::ENEMYNORMAL, res);


	// �X�J�C�h�[��
	res = new RES(RES_T::MODEL, PATH_MDL + "SkyDome/SkyDome.mv1");
	resourcesMap_.emplace(SRC::SKY_DOME, res);

	

	// ���Ƃ����̘f��
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/FallPlanet.mv1");
	resourcesMap_.emplace(SRC::FALL_PLANET, res);

	// ���R�Șf��01
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/FlatPlanet01.mv1");
	resourcesMap_.emplace(SRC::FLAT_PLANET_01, res);

	// ���R�Șf��02
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/FlatPlanet02.mv1");
	resourcesMap_.emplace(SRC::FLAT_PLANET_02, res);

	// �Ō�̘f��
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/LastPlanet.mv1");
	resourcesMap_.emplace(SRC::LAST_PLANET, res);

	// ���ʂȘf��
	res = new RES(RES_T::MODEL, PATH_MDL + "Planet/RoadPlanet.mv1");
	resourcesMap_.emplace(SRC::SPECIAL_PLANET, res);

	// ����
	res = new RES(RES_T::EFFEKSEER, PATH_EFF + "Smoke/Smoke.efkefc");
	resourcesMap_.emplace(SRC::FOOT_SMOKE, res);

	// �^���N
	res = new RES(RES_T::MODEL, PATH_MDL + "Tank/Body.mv1");
	resourcesMap_.emplace(SRC::TANK_BODY, res);
	res = new RES(RES_T::MODEL, PATH_MDL + "Tank/Wheel.mv1");
	resourcesMap_.emplace(SRC::TANK_WHEEL, res);
	res = new RES(RES_T::MODEL, PATH_MDL + "Tank/Barrel.mv1");
	resourcesMap_.emplace(SRC::TANK_BARREL, res);

}

void ResourceManager::Release(void)
{
	for (auto& p : loadedMap_)
	{
		p.second.Release();
	}

	loadedMap_.clear();
}

void ResourceManager::Destroy(void)
{
	Release();
	for (auto& res : resourcesMap_)
	{
		res.second->Release();
		/*delete res.second;*/
	}
	resourcesMap_.clear();
	delete instance_;
}

const Resource& ResourceManager::Load(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return dummy_;
	}
	return res;
}

int ResourceManager::LoadModelDuplicate(SRC src)
{
	Resource& res = _Load(src);
	if (res.type_ == Resource::TYPE::NONE)
	{
		return -1;
	}

	int duId = MV1DuplicateModel(res.handleId_);
	res.duplicateModelIds_.push_back(duId);

	return duId;
}

ResourceManager::ResourceManager(void)
{
}

Resource& ResourceManager::_Load(SRC src)
{

	// ���[�h�ς݃`�F�b�N
	const auto& lPair = loadedMap_.find(src);
	if (lPair != loadedMap_.end())
	{
		return *resourcesMap_.find(src)->second;
	}

	// ���\�[�X�o�^�`�F�b�N
	const auto& rPair = resourcesMap_.find(src);
	if (rPair == resourcesMap_.end())
	{
		// �o�^����Ă��Ȃ�
		return dummy_;
	}

	// ���[�h����
	rPair->second->Load();

	// �O�̂��߃R�s�[�R���X�g���N�^
	loadedMap_.emplace(src, *rPair->second);

	return *rPair->second;
}
